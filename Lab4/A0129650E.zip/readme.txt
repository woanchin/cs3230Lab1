Matriculation Number: A0129650E

I drew a bell curve. To access the bell curve, read the file with 'r' and 
press 'o'. This is the bell curve for CS3241. Yes, I think it's steep.

You can look at it at a C0 or C1 continuity perspective. No difference.
The bell curve is still steep. T.T


