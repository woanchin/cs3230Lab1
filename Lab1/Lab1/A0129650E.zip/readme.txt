A0129650
Tee Woan Chin

I have modified the display() to fit in my drawings. I made a function for each building structure.
Coolest thing about it is that my Ferris Wheel rotates. :D

